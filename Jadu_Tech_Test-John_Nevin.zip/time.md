Time taken:

Research RSS feeds, and decide whether to use 3rd party library for the feed parsing: ~0.5hrs

Decide on basic bootstrap theme and "break-down" in to Twig template: ~1hr

Test 3rd party parser with Symfony: ~0.75hrs

Build app: ~3hrs

Test on a clean virtual machine ~1hr

Whilst researching RSS feeds I soon realised there are different versions/protocols, and they're not strongly adhered to, so, my reasoning for using a third party library was that it may improve compatability.

I also have a security concern - as it is, Twig is rendering the RSS feeds with the "raw" filter, so that if the RSS feed contains html it is rendered. Removing the raw filter would improve the security, but results in HTML code appearing and images not being shown.
