Instructions:

Create MySQL database and user with all privileges.
eg:
	CREATE DATABASE rss_storage;
	
	GRANT ALL PRIVILEGES ON rss_storage.* TO 'rssuser'@'localhost' IDENTIFIED BY 'rssapp';
	
	FLUSH PRIVILEGES;	

Import included sql file rss_storage.sql
eg:
	mysql rss_storage < rss_storage.sql

Unpack rss_test.zip to your web root.

Edit .env with your database details.
eg:
	DATABASE_URL=mysql://rssuser:rssapp@127.0.0.1:3306/rss_storage?serverVersion=10.4.13&charset=utf8
	
Change directory to the app route folder and run composer install.
eg:
	cd /var/www/html/rss_storage
	composer install

Run "symfony serve" - (https://symfony.com/download if not available)

Or if using Apache you need to edit the sites config.
eg:
	ServerAdmin webmaster@localhost
	DocumentRoot /var/www/html/rss_test1/public
	<Directory /var/www/html/rss_test1/public>
	        AllowOverride All
	        Order Allow,Deny
	        Allow from All
		Require all granted
	 </Directory>




